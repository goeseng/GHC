# Good Hands Club

A Korean adaptation of the Men's Sheds model — a task-based community for retired men in their sixties, developed through the Asan Frontier Academy (Team 3).

This is the project's introduction site, intended for international organisations who want to understand our purpose, model, and coalition partners.

## Structure

```
.
├── index.html                     # Single-page site (all styles inline)
├── README.md
└── assets/
    └── logos/                     # Partner organisation logos
        ├── bangahgol.png
        ├── forest100.png
        ├── ohob.png
        ├── seoul-volunteer.png
        └── zaneedle.png
```

## Deploy on GitHub Pages

1. Push this folder to a public GitHub repository.
2. In the repo, go to **Settings → Pages**.
3. Set **Source** to `Deploy from a branch`, select the `main` branch and `/` (root) folder, then **Save**.
4. Your site will be published at `https://<username>.github.io/<repo-name>/`.

## Local preview

Open `index.html` directly in a browser — no build step required.

## Credits

- Background photography: [Unsplash](https://unsplash.com/) (used as placeholders — to be replaced with original Good Hands Club project photography).
- Partner logos: property of each respective organisation.
- Fonts: Instrument Serif and Inter, via Google Fonts.

## Coalition partners

- [Bangahgol Community Welfare Center](https://bangahgol.or.kr/)
- [Hundred Year Forest Social Cooperative](https://forest100.org/)
- [One Heart One Body Movement (OHOB)](https://eng.ohob.or.kr/html/main.php)
- [Seoul Volunteer Center](https://volunteer.seoul.go.kr/main.do)
- [Zaneedle Inc.](https://www.zaneedle.com/)

---

Good Hands Club · [Asan Frontier Academy](https://asan-nanum.org/eng/) · Team 3 · Seoul, Republic of Korea
